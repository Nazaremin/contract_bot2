import os
from dataclasses import dataclass

@dataclass
class Config:
    BOT_TOKEN: str = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
    DATABASE_PATH: str = 'db/contracts.db'
    TEMPLATES_PATH: str = 'templates'
    OUTPUT_PATH: str = 'output'
    ADMIN_USER_ID: int = int(os.getenv('ADMIN_USER_ID', '0'))

config = Config()

